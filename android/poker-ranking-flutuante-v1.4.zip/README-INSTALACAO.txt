POKER RANKING FLUTUANTE 1.4 — PROJETO ANDROID
================================================

Este ZIP contém o código-fonte de um aplicativo Android instalável como APK,
mas NÃO contém o APK já compilado.

Ele reutiliza o motor do Poker Ranking Mobile 1.3:
 - suas duas cartas + até cinco cartas da mesa
 - 52 cartas disponíveis na seleção manual
 - cartas que melhoram a combinação + porcentagens
 - ranking de todas as 10 mãos
 - dados salvos localmente no celular

NOVO: Painel flutuante com arrastar, minimizar, transparência e redimensionar.
Não captura a tela, não espiona o site e não recomenda apostas.

COMO COMPILAR (NO PC):
1. Instale Android Studio (https://developer.android.com/studio).
2. Abra a pasta poker-ranking-flutuante-android-v1.4 em File > Open.
3. Permita a sincronização do Gradle e a instalação do Android SDK 35.
   OBS: este pacote ainda nao inclui o Gradle Wrapper executavel.
   Se o Android Studio pedir um wrapper, gere um em um projeto vazio
   criado pelo Android Studio ou use a compilacao GitHub Actions abaixo.
4. Em Build > Build Bundle(s) / APK(s) > Build APK(s), gere o APK de debug.
5. Localize o arquivo em app/build/outputs/apk/debug/app-debug.apk.
6. Envie esse APK ao celular Android e instale (pode requerer permitir
   instalação de apps dessa origem). Compatível com Android 8.0 ou superior.

COMO USAR:
1. Abra o Poker Ranking no celular.
2. Autorize "Aparecer sobre outros aplicativos" quando solicitado.
3. Toque em "Abrir Poker Ranking flutuante".
4. Abra o Brasa Poker no navegador.
5. Arraste o cabeçalho para mover. "−" minimiza. "×" fecha.
   "◐" altera transparência e "↘" no rodapé redimensiona.

LIMITAÇÕES:
- Alguns celulares, versões do Android ou apps podem bloquear sobreposições.
- O projeto não foi compilado nem testado no dispositivo nesta sessão,
  porque o ambiente não possui Android SDK/Gradle nem acesso para baixá-los.
- É preciso usar Android Studio no computador para obter o APK.
- A janela se sobrepõe a parte da tela; minimize quando quiser tocar no jogo.
- Verifique as regras da plataforma sobre uso de ferramentas externas.
- Embora o app seja local, o Android pode encerrar o serviço em economia de bateria.

Implementação: Java/Android nativo + WebView local (sem acesso à Internet).
Não há permissão de gravação de tela, acessibilidade, nem acesso a outros apps.

ALTERNATIVA SEM ANDROID STUDIO — GITHUB ACTIONS:
1. Crie um repositório GitHub com a pasta raiz do projeto, preservando .github.
2. No GitHub, abra Actions > Compilar APK Android > Run workflow.
3. Após o build, abra o resultado e baixe o artifact Poker-Ranking-Flutuante-APK.
4. Extraia o APK e instale no Android.
   É preciso conta GitHub e a compilação não foi executada nesta sessão.
