package br.com.pokerranking.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Explicitly launched, movable on-screen hand-rank reference. Does not read the game. */
public final class FloatingService extends Service {
    private static final int NOTIFICATION_ID=1104;
    private static final String CHANNEL="poker_rank_overlay";
    private WindowManager wm;private WindowManager.LayoutParams params;
    private LinearLayout root,header;private WebView web;private TextView resize;
    private int fullWidth,fullHeight;private boolean minimized=false;
    private float opacity=1f;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private int screenW(){DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);return m.widthPixels;}
    private int screenH(){DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);return m.heightPixels;}
    private GradientDrawable rounded(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(189,148,72));return d;}
    private TextView headerButton(String text){
        TextView t=new TextView(this);t.setText(text);t.setTextColor(Color.rgb(247,216,157));
        t.setTextSize(16);t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(Color.rgb(39,44,51));return t;
    }
    @Override public void onCreate(){super.onCreate();
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        notification();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        int sw=screenW(),sh=screenH();
        fullWidth=Math.min(dp(304),sw-dp(14));
        fullHeight=Math.min(dp(415),sh-dp(95));
        params=new WindowManager.LayoutParams(fullWidth,fullHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        params.x=sw-fullWidth-dp(7);params.y=dp(52);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(Color.rgb(14,19,26),12));root.setClipToOutline(true);
        header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);header.setBackgroundColor(Color.rgb(34,32,28));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(39));root.addView(header,hp);
        TextView title=headerButton("♠  POKER RANKING  •  ARRASTE");title.setTextSize(10);title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(9),0,dp(2),0);title.setBackgroundColor(Color.TRANSPARENT);
        header.addView(title,new LinearLayout.LayoutParams(0,-1,1f));
        title.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int px,py;
            @Override public boolean onTouch(View v,MotionEvent event){
                if(event.getAction()==MotionEvent.ACTION_DOWN){dx=event.getRawX();dy=event.getRawY();px=params.x;py=params.y;return true;}
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    params.x=Math.max(0,Math.min(screenW()-params.width,px+(int)(event.getRawX()-dx)));
                    params.y=Math.max(0,Math.min(screenH()-params.height,py+(int)(event.getRawY()-dy)));
                    updateWindow();return true;
                }return event.getAction()==MotionEvent.ACTION_UP;
            }
        });
        TextView alphaBtn=headerButton("◐");header.addView(alphaBtn,new LinearLayout.LayoutParams(dp(32),-1));
        alphaBtn.setOnClickListener(v->{opacity=opacity==1f?.88f:opacity==.88f?.72f:1f;root.setAlpha(opacity);});
        TextView minimizeBtn=headerButton("−");header.addView(minimizeBtn,new LinearLayout.LayoutParams(dp(32),-1));
        minimizeBtn.setOnClickListener(v->toggleMinimize(minimizeBtn));
        TextView closeBtn=headerButton("×");header.addView(closeBtn,new LinearLayout.LayoutParams(dp(32),-1));
        closeBtn.setOnClickListener(v->stopSelf());
        web=new WebView(this);
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(false);settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setBackgroundColor(Color.rgb(16,19,24));
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return !url.startsWith("file:///android_asset/");}
        });
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1f));
        resize=headerButton("↘  ARRASTE PARA REDIMENSIONAR");resize.setTextSize(10);
        resize.setTextColor(Color.rgb(181,190,203));
        root.addView(resize,new LinearLayout.LayoutParams(-1,dp(24)));
        resize.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int w,h;
            @Override public boolean onTouch(View v,MotionEvent event){
                if(event.getAction()==MotionEvent.ACTION_DOWN){dx=event.getRawX();dy=event.getRawY();w=params.width;h=params.height;return true;}
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    fullWidth=Math.max(dp(256),Math.min(screenW()-params.x,w+(int)(event.getRawX()-dx)));
                    fullHeight=Math.max(dp(260),Math.min(screenH()-params.y-dp(10),h+(int)(event.getRawY()-dy)));
                    params.width=fullWidth;params.height=fullHeight;updateWindow();return true;
                }return event.getAction()==MotionEvent.ACTION_UP;
            }
        });
        wm.addView(root,params);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void toggleMinimize(TextView btn){
        minimized=!minimized;
        if(minimized){web.setVisibility(View.GONE);resize.setVisibility(View.GONE);
            params.width=dp(230);params.height=dp(39);btn.setText("□");}
        else{web.setVisibility(View.VISIBLE);resize.setVisibility(View.VISIBLE);
            params.width=Math.min(fullWidth,screenW()-dp(10));params.height=Math.min(fullHeight,screenH()-dp(60));
            params.x=Math.min(params.x,screenW()-params.width);params.y=Math.min(params.y,screenH()-params.height);btn.setText("−");}
        updateWindow();
    }
    private void updateWindow(){try{if(root!=null&&wm!=null)wm.updateViewLayout(root,params);}catch(Exception ignored){}}
    private void notification(){
        NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Poker Ranking flutuante",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Indica que o painel flutuante está aberto");manager.createNotificationChannel(ch);
        }
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification notification=nb.setSmallIcon(R.drawable.ic_notification).setContentTitle("Poker Ranking flutuante")
            .setContentText("Painel de consulta ativo. Toque para abrir as opções.")
            .setOngoing(true).setContentIntent(pi).build();
        startForeground(NOTIFICATION_ID,notification);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        if(wm!=null&&root!=null){try{wm.removeView(root);}catch(Exception ignored){}}
        if(web!=null){web.stopLoading();web.destroy();web=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
