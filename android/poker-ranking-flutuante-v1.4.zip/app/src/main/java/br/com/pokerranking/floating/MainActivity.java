package br.com.pokerranking.floating;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Launcher and explicit user permission entry point. No accessibility or screen capture. */
public class MainActivity extends Activity {
    private TextView status;
    private int dp(float a) {return (int)(a*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(int color, int stroke) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));d.setStroke(dp(1),stroke);return d;
    }
    private TextView label(String msg,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(msg);t.setTextSize(sp);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_HORIZONTAL);t.setPadding(dp(7),dp(9),dp(7),dp(9));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private Button action(String msg, LinearLayout content, View.OnClickListener listener){
        Button b=new Button(this);b.setText(msg);b.setAllCaps(false);b.setTextColor(Color.rgb(255,231,182));
        b.setBackground(background(Color.rgb(41,47,56),Color.rgb(167,129,63)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.topMargin=dp(11);content.addView(b,lp);
        b.setOnClickListener(listener);return b;
    }
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(17,21,26));getWindow().setNavigationBarColor(Color.rgb(17,21,26));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setBackgroundColor(Color.rgb(16,19,24));
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22),dp(30),dp(22),dp(32));sv.addView(page);setContentView(sv);
        page.addView(label("♠  POKER RANKING",25,Color.rgb(241,202,122),true));
        page.addView(label("JANELA FLUTUANTE • ANDROID",12,Color.rgb(180,188,202),true));
        status=label("",14,Color.WHITE,false);page.addView(status);
        page.addView(label("1. Autorize aparecer sobre outros apps.\n2. Abra o painel flutuante.\n3. Volte ao navegador para consultar o ranking.",15,Color.rgb(225,229,238),false));
        action("1 · Permitir janela sobre outros apps",page,v->{
            if(Build.VERSION.SDK_INT>=23){
                Intent intent=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName()));startActivity(intent);
            }else Toast.makeText(this,"Permissão já disponível",Toast.LENGTH_SHORT).show();
        });
        action("2 · Abrir Poker Ranking flutuante",page,v->{
            if(!Settings.canDrawOverlays(this)){
                Toast.makeText(this,"Ative a permissão primeiro",Toast.LENGTH_LONG).show();return;
            }
            Intent s=new Intent(this,FloatingService.class);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
            Toast.makeText(this,"Painel aberto. Volte ao Chrome para jogar.",Toast.LENGTH_LONG).show();
        });
        action("Abrir Brasa Poker no navegador",page,v->{
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://brasa.poker/")));}
            catch(Exception e){Toast.makeText(this,"Abra o Brasa Poker no navegador",Toast.LENGTH_LONG).show();}
        });
        action("Fechar painel flutuante",page,v->stopService(new Intent(this,FloatingService.class)));
        page.addView(label("O painel pode ser movido, minimizado e redimensionado. A análise mostra quais cartas melhoram sua combinação, não prevê resultados nem indica apostas.",12,Color.rgb(168,178,192),false));
        updateStatus();
    }
    @Override public void onResume(){super.onResume();if(status!=null)updateStatus();}
    private void updateStatus(){status.setText(Settings.canDrawOverlays(this)?
        "✓ Permissão de sobreposição ativa":"⚠ Ainda falta autorizar a sobreposição");}
}
