/* Cálculo local, sem acesso à mesa ou Internet. Texas Hold'em: melhor mão de 5 cartas. */
(function(root){
'use strict';
const RANKS='23456789TJQKA';
const SUITS=['s','h','d','c'];
const SYMBOL={s:'♠',h:'♥',d:'♦',c:'♣'};
const NAMES=['Carta alta','Um par','Dois pares','Trinca','Sequência','Flush','Full House','Quadra','Straight Flush'];
const deck=SUITS.flatMap(s=>[...RANKS].map(r=>r+s));
const rank=c=>RANKS.indexOf(c[0])+2;
const validCard=c=>typeof c==='string'&&c.length===2&&RANKS.includes(c[0])&&SUITS.includes(c[1]);
const pretty=c=>(c[0]==='T'?'10':c[0])+SYMBOL[c[1]];
const compare=(a,b)=>{for(let i=0;i<Math.max(a.length,b.length);i++){let d=(a[i]||0)-(b[i]||0);if(d)return Math.sign(d)}return 0};
function straightHigh(vals){
 const u=[...new Set(vals)].sort((a,b)=>b-a);
 if(u.includes(14))u.push(1);
 for(let i=0;i<=u.length-5;i++){if(u[i]-u[i+4]===4)return u[i];}
 return 0;
}
function evaluate5(cards){
 if(cards.length!==5||!cards.every(validCard)||new Set(cards).size!==5)throw Error('Precisamos de 5 cartas diferentes.');
 const vals=cards.map(rank).sort((a,b)=>b-a);
 const flush=cards.every(c=>c[1]===cards[0][1]);
 const straight=straightHigh(vals);
 if(flush&&straight)return [8,straight];
 const counts=new Map();vals.forEach(v=>counts.set(v,(counts.get(v)||0)+1));
 const sets=[...counts].map(([r,n])=>({r,n})).sort((a,b)=>b.n-a.n||b.r-a.r);
 if(sets[0].n===4)return [7,sets[0].r,sets[1].r];
 if(sets[0].n===3&&sets[1].n===2)return [6,sets[0].r,sets[1].r];
 if(flush)return [5,...vals];
 if(straight)return [4,straight];
 if(sets[0].n===3)return [3,sets[0].r,...sets.slice(1).map(s=>s.r).sort((a,b)=>b-a)];
 if(sets[0].n===2&&sets[1].n===2){const p=[sets[0].r,sets[1].r].sort((a,b)=>b-a);return [2,...p,sets[2].r];}
 if(sets[0].n===2)return [1,sets[0].r,...sets.slice(1).map(s=>s.r).sort((a,b)=>b-a)];
 return [0,...vals];
}
function evaluateBest(cards){
 if(cards.length<5||cards.length>7||!cards.every(validCard)||new Set(cards).size!==cards.length)throw Error('Escolha de 5 a 7 cartas diferentes.');
 let best=null;
 for(let a=0;a<cards.length-4;a++)for(let b=a+1;b<cards.length-3;b++)for(let c=b+1;c<cards.length-2;c++)for(let d=c+1;d<cards.length-1;d++)for(let e=d+1;e<cards.length;e++){
  const v=evaluate5([cards[a],cards[b],cards[c],cards[d],cards[e]]);
  if(!best||compare(v,best)>0)best=v;
 }
 return best;
}
const nameOf=score=>score[0]===8&&score[1]===14?'Royal Flush':NAMES[score[0]];
function choose(n,k){let x=1;for(let i=1;i<=k;i++)x=x*(n-i+1)/i;return x;}
function analyze(hole,board){
 const selected=[...hole,...board];
 if(!selected.every(validCard)||new Set(selected).size!==selected.length||hole.length>2||board.length>5)throw Error('Cartas inválidas ou repetidas.');
 const remaining=deck.filter(c=>!selected.includes(c));
 if(hole.length!==2)return {stage:'incomplete',message:'Selecione suas duas cartas.'};
 if(board.length>0&&board.length<3)return {stage:'waitingFlop',handName:'Flop incompleto',message:'Adicione as 3 cartas do flop para ver quais cartas podem melhorar sua mão no turn.'};
 if(board.length===0){
  const same=hole[0][0]===hole[1][0];
  const matching=remaining.filter(c=>hole.some(h=>h[0]===c[0]));
  const groups=same?[{title:'Trinca (terceiro valor igual)',cards:matching}]:[
   {title:`Par de ${pretty(hole[0])}`,cards:matching.filter(c=>c[0]===hole[0][0])},
   {title:`Par de ${pretty(hole[1])}`,cards:matching.filter(c=>c[0]===hole[1][0])}
  ];
  const probability=100*(1-choose(50-matching.length,3)/choose(50,3));
  return {stage:'preflop',handName:same?'Um par':'Carta alta',groups,matchingCount:matching.length,remainingCount:50,probability,
   suited:hole[0][1]===hole[1][1],connected:Math.abs(rank(hole[0])-rank(hole[1]))<=4,
   message:'As cartas abaixo ajudam a formar um par ou uma trinca no flop.'};
 }
 const current=evaluateBest(selected);
 if(board.length===5)return {stage:'river',handName:nameOf(current),score:current,message:'River completo. Não há próxima carta comunitária.'};
 const improvements=new Map();const small=[];
 for(const candidate of remaining){
  const next=evaluateBest([...selected,candidate]);
  const cmp=compare(next,current);
  if(cmp>0){
   if(next[0]>current[0]){const label=nameOf(next);if(!improvements.has(label))improvements.set(label,{title:label,cards:[],strength:next[0]});improvements.get(label).cards.push(candidate)}
   else small.push(candidate);
  }
 }
 const groups=[...improvements.values()].sort((a,b)=>b.strength-a.strength).map(({title,cards})=>({title,cards:cards.sort((a,b)=>rank(b)-rank(a)||SUITS.indexOf(a[1])-SUITS.indexOf(b[1]))}));
 small.sort((a,b)=>rank(b)-rank(a)||SUITS.indexOf(a[1])-SUITS.indexOf(b[1]));
 const count=groups.reduce((a,g)=>a+g.cards.length,0);
 return {stage:board.length===3?'flop':'turn',handName:nameOf(current),score:current,groups,minor:small,matchingCount:count,remainingCount:remaining.length,probability:100*count/remaining.length,
  message:count?'Estas cartas aumentam o TIPO da sua melhor combinação.':'Nenhuma carta isolada sobe o tipo da sua combinação no próximo turno.'};
}
const API={RANKS,SUITS,SYMBOL,NAMES,deck,rank,pretty,compare,evaluate5,evaluateBest,nameOf,analyze};
if(typeof module==='object'&&module.exports)module.exports=API;
root.PokerEngine=API;
})(typeof window==='object'?window:globalThis);
