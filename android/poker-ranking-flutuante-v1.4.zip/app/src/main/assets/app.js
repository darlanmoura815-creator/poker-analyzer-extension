'use strict';
const E=window.PokerEngine, $=id=>document.getElementById(id);
const KEY='poker-ranking-combinacoes-v1.1';
let hole=[],board=[],tab='analyze',lastCards=[];
try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');if(Array.isArray(saved.hole)&&Array.isArray(saved.board)){const all=[...saved.hole,...saved.board];if(saved.hole.length<=2&&saved.board.length<=5&&all.every(c=>E.deck.includes(c))&&new Set(all).size===all.length){hole=saved.hole;board=saved.board;}}}catch(_){/* usar estado vazio */}
function persist(){try{localStorage.setItem(KEY,JSON.stringify({hole,board}));}catch(_){}}
function button(text,title,cls,onClick){const el=document.createElement('button');el.type='button';el.textContent=text;el.title=title||text;el.className=cls;el.addEventListener('click',onClick);return el;}
function addOrRemove(card){
 if(hole.includes(card)){hole=hole.filter(c=>c!==card)}
 else if(board.includes(card)){board=board.filter(c=>c!==card)}
 else if(hole.length<2){hole.push(card);lastCards.push(card)}
 else if(board.length<5){board.push(card);lastCards.push(card)}
 persist();render();
}
function renderSlots(){
 for(const [id,arr,n,kind] of [['holeSlots',hole,2,'sua mão'],['boardSlots',board,5,'mesa']]){
  const wrap=$(id);wrap.replaceChildren();for(let i=0;i<n;i++){
   const c=arr[i];const node=button(c?E.pretty(c):'·',c?`Remover ${E.pretty(c)} da ${kind}`:`Espaço ${i+1} da ${kind}`,`slot ${c?'filled':''} ${c&&'hd'.includes(c[1])?'red':''}`,()=>{if(c)addOrRemove(c)});
   if(!c)node.disabled=true;wrap.append(node);
  }
 }
 $('nextSelection').textContent=hole.length<2?`Selecione sua mão (${hole.length}/2).`:board.length<5?`Agora selecione a mesa (${board.length}/5).`:'Mão completa — river.';
}
function cardsInto(container,cards){container.replaceChildren();for(const c of cards){const el=document.createElement('span');el.className='mini-card '+('hd'.includes(c[1])?'red':'');el.textContent=E.pretty(c);el.title=c;container.append(el)}}
function renderResult(a){
 const stages={incomplete:'COMECE',preflop:'PRÉ-FLOP',waitingFlop:'FLOP',flop:'FLOP',turn:'TURN',river:'RIVER'};
 $('stage').textContent=stages[a.stage]||'MÃO';$('handName').textContent=a.handName||'Selecione 2 cartas';
 $('minorPanel').hidden=true;$('minorPanel').open=false;
 $('improvementList').replaceChildren();
 if(a.stage==='incomplete'||a.stage==='waitingFlop'){$('mainCount').textContent='—';$('mainLabel').textContent='Cartas que ajudam';$('mainProbability').textContent='';$('resultHelp').textContent=a.message;return}
 if(a.stage==='river'){$('mainCount').textContent='✓';$('mainLabel').textContent='Combinação final';$('mainProbability').textContent='Nenhuma próxima carta';$('resultHelp').textContent=a.message;return}
 $('mainCount').textContent=a.matchingCount;
 $('mainLabel').textContent=a.stage==='preflop'||a.stage==='waitingFlop'?'Cartas que combinam com sua mão':'Cartas que sobem sua combinação';
 $('mainProbability').textContent=a.stage==='preflop'||a.stage==='waitingFlop'?`${a.probability.toFixed(1)}% de ver ≥1 dessas no flop`:`${a.probability.toFixed(1)}% na próxima carta (${a.matchingCount}/${a.remainingCount})`;
 $('resultHelp').textContent=a.message;
 if(a.stage==='preflop'||a.stage==='waitingFlop'){
  const hints=[];if(a.suited)hints.push('Mesmo naipe: potencial futuro de flush.');if(a.connected)hints.push('Valores próximos: potencial futuro de sequência.');if(hints.length)$('resultHelp').textContent+=' '+hints.join(' ');
 }
 for(const g of a.groups||[]){if(!g.cards.length)continue;const line=document.createElement('div');line.className='improvement-group';const label=document.createElement('b');label.textContent=g.title+` · ${g.cards.length} carta${g.cards.length!==1?'s':''}`;const list=document.createElement('div');list.className='mini-list';cardsInto(list,g.cards);line.append(label,list);$('improvementList').append(line)}
 if(!a.groups?.some(g=>g.cards.length)&&a.stage!=='river'){
  const span=document.createElement('span');span.textContent='Nenhuma carta melhora o tipo imediatamente.';span.style.cssText='font-size:10px;color:#c9d0da';$('improvementList').append(span);
 }
 if(a.minor?.length){$('minorPanel').hidden=false;$('minorCount').textContent=a.minor.length;cardsInto($('minorList'),a.minor)}
}
function renderDeck(a){
 const used=new Set([...hole,...board]),primary=new Set((a.groups||[]).flatMap(g=>g.cards||[])),secondary=new Set(a.minor||[]);
 const wrap=$('deck');wrap.replaceChildren();
 for(const card of E.deck){const cl=['deck-card'];if('hd'.includes(card[1]))cl.push('red');if(used.has(card))cl.push('used');else if(primary.has(card))cl.push('out');else if(secondary.has(card))cl.push('minor-out');
  const what=used.has(card)?'remover carta':primary.has(card)?'melhora sua combinação':secondary.has(card)?'melhora a mão dentro da mesma combinação':'selecionar carta';
  const btn=button(E.pretty(card),`${E.pretty(card)} — ${what}`,cl.join(' '),()=>addOrRemove(card));btn.setAttribute('aria-pressed',String(used.has(card)));wrap.append(btn);
 }
}
function render(){const a=E.analyze(hole,board);renderSlots();renderResult(a);renderDeck(a);persist()}
$('undoBtn').addEventListener('click',()=>{while(lastCards.length){const last=lastCards.pop();if(hole.includes(last)||board.includes(last)){addOrRemove(last);return}}if(board.length)addOrRemove(board.at(-1));else if(hole.length)addOrRemove(hole.at(-1))});
$('resetBtn').addEventListener('click',()=>{hole=[];board=[];lastCards=[];render()});
function changeTab(next){tab=next;const rank=next==='ranking';$('rankingView').hidden=!rank;$('analyzeView').hidden=rank;$('tabAnalyze').classList.toggle('active',!rank);$('tabRanking').classList.toggle('active',rank);$('tabAnalyze').setAttribute('aria-selected',String(!rank));$('tabRanking').setAttribute('aria-selected',String(rank));}
$('tabAnalyze').addEventListener('click',()=>changeTab('analyze'));
$('tabRanking').addEventListener('click',()=>changeTab('ranking'));
render();
